<?php

$server_name=”localhost”;

$username=”root”;

$password=””;

$database_name=”testdb″;

$conn=mysqli_connect($server_name,$username,$password,$database_name);
// check the connection
if(!$conn)
{die("Connection Failed:" . mysqli_connect_error());}
if(isset($_POST['save']))
{
	$fullName = $_POST['fullName'];
	$Surname = $_POST['Surname'];
	$email = $_POST['email'];
	$phoneNumber = $_POST['phoneNumber'];
	$City = $_POST['City'];
	$town = $_POST['town'];
	$DateOfBirth = $_POST['DateOfBirth'];
	$gender = $_POST['gender'];
	// inserting the data into mysql database 
	$sql_query = "INSERT INTO entry_details (fullName,Surname,email,phoneNumbe,City,town,DateOfBirth,gender)
	VALUES ('$fullName','$Surname','$email','$phoneNumber','$City','$town','$DateOfBirth','$gender')";
	if (mysqli_query($conn, $sql_query))
	{
		echo "New Details Entry inserted successfully !";
	}
	else
	{
		echo "error"; . $sql . "" .mysql_error($conn);
	}
	mysql_close($conn);

}
?>