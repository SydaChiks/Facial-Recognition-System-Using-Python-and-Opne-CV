AU Clinic Managament Information System

FIRST Download

1.XAMPP

2."TEXT EDITOR" NOTEPAD++ OR SUBLIME TEXT 3 / ETC.

3. Locate the AU Clinic Management Information System zip file.

4. Extract the file and copy "AU Clinic Management Information System" folder

5.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

6. Open PHPMyAdmin (http://localhost/phpmyadmin)

7. Create a database with name clinic

8. Import clinic.sql file(given inside the zip package in SQL file folder)

9.Run the script http://localhost/AU Clinic Management Inforamtion System/login.php


**LOGIN DETAILS** 

Doctor
user: sydneychikanya@gmail.com
pass: sida123

user: tatendagondwe@gmail.com
pass:phoenix789

user:mandivengam@africau.edu
pass:hospital

user:sibandat@africau.edu
pass:hospital

Admin
user: mutsamwanza@gmail.com
pass: hacking

Patient
Phone Number: 0734030303
Patient Number: 4066

